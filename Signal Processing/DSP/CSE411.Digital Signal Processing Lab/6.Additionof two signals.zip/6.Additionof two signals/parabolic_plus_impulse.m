
t=-10:.1:10;

parabola=0.5*(t.^2);
subplot(2,2,1);
plot(t,parabola);
xlabel('Continuous time n------>');
ylabel('Amplitude------>');
title('unit parabolic continuous sequence');



for i=1:length(t)
    if t(i)<0
        y(i)=0;
    else if t(i)==0
            y(i)=1;
        else if t(i)>0
               y(i)=0;
            end
        end
    end
end
subplot(2,2,2);            
plot(t,y);
xlabel('Continuous time n------>');
ylabel('Amplitude------>');
title('unit impulse discrete sequence');


for i=1:length(y);
    add(i)=parabola(i)+y(i);
end

subplot(2,2,3:4);
plot(t,add);
xlabel('Time n-->');
ylabel('Amplitude-->');
axis([-2 2 0 1]);
title('Addition of Unit parabola and impulse Sequence');