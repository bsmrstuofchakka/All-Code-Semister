% continuous sine funtion
t=-1:0.01:2;
f=2;
a=1;
y1=a*sin(2*pi*f*t);
subplot(2,2,1);
plot(t,y1);
xlabel(' Continuous Time Period');
ylabel('Amplitude');
title('Sine Function');

% reverse continuous sine funtion
t=-1:0.01:2;
f=2;
a=1;
y2=a*sin(2*pi*f*(-t));
subplot(2,2,2);
plot(t,y2);
xlabel(' Continuous Time Period');
ylabel('Amplitude');
title('Sine Function');

% even sine funtion
t=-1:0.01:2;
f=2;
a=1;
ye=.5*(y1+y2);
subplot(2,2,3);
plot(t,ye);
xlabel(' Continuous Time Period');
ylabel('Amplitude');
title('Sine Function');

% odd sine funtion
t=-1:0.01:2;
f=2;
a=1;
yo=.5*(y1-y2);
subplot(2,2,4);
plot(t,yo);
xlabel(' Continuous Time Period');
ylabel('Amplitude');
title('Sine Function');