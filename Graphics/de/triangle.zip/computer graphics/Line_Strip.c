//#include<windows.h>
#include <GL/glut.h>
#include <stdlib.h>

static GLfloat spin = 0;

void display(void)
{
 glClear(GL_COLOR_BUFFER_BIT);
	//glPushMatrix();
	//glRotatef(spin, 0.0, 0.0, 1.0);
	//r=1 , g=0 ,b=0 ;
	glColor3f(r, g, b);
//	glColor3f(1.0f, 0.0f, 0.0f);

	glBegin(GL_LINE_STRIP);
	float r=1, g=0 , b=0 ;
	float x , y , r =10 , d=3-2*r;
	x=0 ; y= r;
	while(x<=y)
    {

        glVertex3f (x +h , y +k, 0.0);
        glVertex3f (y+h, x+k, 0.0);
        glVertex3f (-y+h , x+k, 0.0);
        glVertex3f (-x +h, y+k, 0.0);
        glVertex3f (-x +h, -y+k, 0.0);
        glVertex3f (-y +h, -x+k, 0.0);
        glVertex3f (y +h, -x+k, 0.0);
        glVertex3f (x +h, -y+k, 0.0);

        if(d<0)
            d= d+4*x+6 ;
        else{
            d= d+ 4*(x-y)+10;
            y=y-0.3;
        }
        x=x+0.3 ;
    }

	glEnd();




	//glPopMatrix();
	glFlush();
}


void init(void)
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glOrtho(-50.0, 50.0, -50.0, 50.0, -1.0, 1.0);
}


void spe_key(int key, int x, int y)
{

	switch (key) {
case GLUT_KEY_LEFT:

                k=k+5;
              glutPostRedisplay();

			break;

		case GLUT_KEY_RIGHT:
			//spin = -5

        if (flag==0)
			 r=1, g= 0, b=0 ;
        else if (flag==1)
			 r=0 , g= 1, b=0 ;
        else if (flag==2)
			 r=0 , g= 0, b=1 ;
        else if (flag==3)
			 r=1 , g= 1, b=1 ;
        else if (flag==4)
            flag =-1 ;
			glutPostRedisplay();
			flag++ ;


			break;

	  default:
			break;
	}
}


/*
 *
 *  Register mouse input callback functions
 */


int main()
{
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize (700,700);
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("mist");
	init();
	glutDisplayFunc(display);

	glutSpecialFunc(spe_key);

	glutMainLoop();
	return 0;   /* ANSI C requires main to return int. */
}

