#include <GL/glut.h>
#include <stdlib.h>

static GLfloat spin = 0;

void display(void)
{
    GLint i,j,r,g,b,a,x,y;
	
	glClear(GL_COLOR_BUFFER_BIT);
	
	glColor3f(1,1,1);
		
	glBegin(GL_LINES);
		glVertex3f(0,50,0);
		glVertex3f(0,-50,0);
	glEnd();

	glBegin(GL_LINES);
		glVertex3f(50,0,0);
		glVertex3f(-50,0,0);
	glEnd();

	y=-1;
	
	for(i = 0 ; i < 12 ; i++)
	{
		x=-1;
		y = y+4;
		for(j = 0 ; j < 12 ; j++)
		{
			x=x+4;

			a=(i+j)%3;
			
			if(a == 0){r=1;g=0;b=0;}
			if(a == 1){r=0;g=1;b=0;}
			if(a == 2){r=0;g=0;b=1;}
			
			glPushMatrix();
			glTranslatef(x,y,0);
			glColor3f(r, g, b);
			glRectf(2,2,-2,-2);
			
			glPopMatrix();
		}
	}

	
	
	glFlush();
}


void init(void) 
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glOrtho(-50.0, 50.0, -50.0, 50.0, -1.0, 1.0);
}


int main()
{
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize (500, 500); 
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("mist");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0; 
}

